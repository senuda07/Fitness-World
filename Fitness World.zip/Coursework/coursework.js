<button onclick="topFunction()" id="myBtn" title="Go to top">Back To Top</button>

//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {
    scrollFunction()
};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
    } else {
        mybutton.style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}


function getRadioValue(radioArray) {
    var i;
    for (i = 0; i < radioArray.length; i++) {
        if (radioArray[i].checked) {
            return radioArray[i].value;
        }
    }
    return -1;
}

function timer() {
    var setTimer = setInterval(showResults, 60000);
}

function goToTop() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}

function reviewAnswers() {
    var homeBox = document.getElementById("home_area").hidden = true;
    var questionBox = document.getElementById("ques_area").hidden = false;
    var resultsBox = document.getElementById("results_area").hidden = true;
    document.body.style.backgroundColor = "#63656a";
}

function showQuestions() {
    var homeBox = document.getElementById("home_area").hidden = true;
    var questionBox = document.getElementById("ques_area").hidden = false;
    var resultsBox = document.getElementById("results_area").hidden = true;

    timer();
}

function showResults() {
    var homeBox = document.getElementById("home_area").hidden = true;
    var questionBox = document.getElementById("ques_area").hidden = true;
    var resultsBox = document.getElementById("results_area").hidden = false;

    var selectedAnswers = [];
    for (let j = 0; j < 10; j++) {
        var name = "answer" + (j + 1);
        var allAnswers = [];
        allAnswers = document.getElementsByName(name);

        var selectedAnswer = getRadioValue(allAnswers);
        selectedAnswers[j] = selectedAnswer;
    }

    let score = 0;
    const correctAnswers = [3, 3, 1, 2, 1, 1, 1, 1, 1, 1];
    for (let i = 0; i < selectedAnswers.length; i++) {
        var id = "q" + (i + 1);
        if (selectedAnswers[i] == correctAnswers[i]) {
            score += 2;
            document.getElementById(id).innerHTML = "correct";
        } else {
            score -= 1;
            document.getElementById(id).innerHTML = "incorrect";
        }
    }

    document.getElementById("total").innerHTML = "Your score is " + score;

    // document.body.style.backgroundColor = "yellow";

    if (score > 16) {
        document.body.style.backgroundColor = "#00ff00";
    } else if (score >= 4) {
        document.body.style.backgroundColor = "yellow";
    } else {
        document.body.style.backgroundColor = "#ff0000";
    }
}
