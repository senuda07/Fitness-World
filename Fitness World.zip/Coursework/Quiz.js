function showQuestions() {
  // Show the question area
  document.getElementById('question-area').removeAttribute('hidden');
  
  // Hide the home area
  document.getElementById('quiz-welcome-area').setAttribute('hidden', true);
}
    function showResults() {
  // get all the answer elements
  const answers = document.querySelectorAll('.answer');
  
  // initialize variables to store the score and number of correct answers
  let score = 0;
  let correctAnswers = 0;
  
  // iterate over the answer elements and check the user's answers
  answers.forEach(answer => {
    if (answer.checked) {
      if (answer.value === '2') {
        score += 2; // add 2 points for a correct answer
        correctAnswers++;
      } else {
        score -= 1; // deduct 1 point for an incorrect answer
      }
    }
  });
  
  // create the results message
  const message = `!!QUIZ IS COMPLETE!! You have answered ${correctAnswers} out of the 5 questions correctly and scored ${score} points!`;
  
  // display the results message in a popup
  alert(message);
}
